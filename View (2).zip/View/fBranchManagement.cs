﻿using bankManagement.Controller;
using bankManagement.Model;
using bankManagement.View;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bankManagement
{
    public partial class fBranchManagement : Form, IView
    {
        branchController branchCtrl;
        branchModel branchM;

        public fBranchManagement()
        {
            InitializeComponent();
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            branchCtrl = new branchController();
            branchM = new branchModel();

            // Gọi Load dữ liệu từ Controller khi khởi tạo Form
            LoadDataToGridView();
        }
        public void SetDataToText()
        {
            txtID.Text = branchM.id;
            txbTenChiNhanh.Text = branchM.name;
            txbSoNha.Text = branchM.house_no;
            comboBoxThanhPho.Text = branchM.city;
        }

        public void GetDataFromText()
        {
            string id = this.txtID.Text;
            string name = this.txbTenChiNhanh.Text;
            string house_no = this.txbSoNha.Text;
            string city = this.comboBoxThanhPho.Text;
            branchM.id = id;
            branchM.name = name;
            branchM.house_no = house_no;
            branchM.city = city;
        }

        public void LoadDataToGridView()
        {
            // Gọi hàm GetDataFromText để lấy dữ liệu từ các control
            GetDataFromText();

            // Sau khi đã có dữ liệu từ GetDataFromText, tiếp tục load dữ liệu
            branchCtrl.Load();
            dataGridViewBranch.DataSource = branchCtrl.Items.OfType<branchModel>().ToList();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ các trường nhập liệu
            GetDataFromText();

            // Kiểm tra đối tượng branchM đã tồn tại trong cơ sở dữ liệu hay chưa
            if (branchCtrl.IsExist(branchM))
            {
                // Nếu tồn tại, thì gọi hàm Update
                bool updated = branchCtrl.Update(branchM);
                if (updated)
                {
                    MessageBox.Show("Cập nhật chi nhánh thành công!");
                }
                else
                {
                    MessageBox.Show("Cập nhật chi nhánh thất bại!");
                }
            }
            else
            {
                // Nếu không tồn tại, thì gọi hàm Create
                bool created = branchCtrl.Create(branchM);
                if (created)
                {
                    MessageBox.Show("Thêm chi nhánh mới thành công!");
                }
                else
                {
                    MessageBox.Show("Thêm chi nhánh mới thất bại!");
                }
            }
            fBranchManagement fBranchManagement = new fBranchManagement();
            this.Close();
            fBranchManagement.ShowDialog();
        }

        private void dataGridViewBranch_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Kiểm tra xem dòng được chọn có hợp lệ không
            if (e.RowIndex >= 0)
            {
                // Lấy dữ liệu từ dòng được chọn trong DataGridView
                DataGridViewRow row = dataGridViewBranch.Rows[e.RowIndex];

                // Gán dữ liệu từ DataGridView vào biến toàn cục branchM
                branchM = new branchModel
                (
                    row.Cells["id"].Value.ToString(),   // Cột ID
                    row.Cells["name"].Value.ToString(), // Cột tên chi nhánh
                    row.Cells["house_no"].Value.ToString(), // Cột số nhà
                    row.Cells["city"].Value.ToString()  // Cột thành phố
                );

                // Hiển thị dữ liệu lên các ô nhập liệu (TextBox, ComboBox)
                SetDataToText();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem ô ID có dữ liệu không
            if (!string.IsNullOrEmpty(txtID.Text))
            {
                // Tạo đối tượng branchModel với ID lấy từ TextBox
                branchModel branch = new branchModel
                {
                    id = txtID.Text
                };

                // Gọi phương thức Delete để xóa bản ghi trong cơ sở dữ liệu
                bool isDeleted = branchCtrl.Delete(branch);

                // Kiểm tra kết quả và thông báo cho người dùng
                if (isDeleted)
                {
                    MessageBox.Show("Đã xóa chi nhánh thành công!");
                    // Cập nhật lại DataGridView (nạp lại dữ liệu)
                }
                else
                {
                    MessageBox.Show("Xóa chi nhánh thất bại!");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn chi nhánh cần xóa!");
            }
            fBranchManagement fBranchManagement = new fBranchManagement();
            this.Close();
            fBranchManagement.ShowDialog();
        }

    }
}
