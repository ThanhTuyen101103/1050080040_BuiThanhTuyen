﻿namespace bankManagement
{
    partial class fMainManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMainManager));
            menuStrip2 = new MenuStrip();
            menuFile = new ToolStripMenuItem();
            menuItemLogin = new ToolStripMenuItem();
            menuItemLogout = new ToolStripMenuItem();
            menuSystem = new ToolStripMenuItem();
            employeeToolStripMenuItem = new ToolStripMenuItem();
            branchToolStripMenuItem = new ToolStripMenuItem();
            menuBanking = new ToolStripMenuItem();
            ToolStripMenuItemcreateCustomer = new ToolStripMenuItem();
            depositAmountToolStripMenuItem = new ToolStripMenuItem();
            withToolStripMenuItem = new ToolStripMenuItem();
            transactionAmountToolStripMenuItem = new ToolStripMenuItem();
            balaceToolStripMenuItem = new ToolStripMenuItem();
            transactionLogToolStripMenuItem = new ToolStripMenuItem();
            menuHelp = new ToolStripMenuItem();
            userGuideToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            toolStrip1 = new ToolStrip();
            toolbarBranchPrint = new ToolStripButton();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabelBankSystemManagement = new ToolStripStatusLabel();
            toolStripButton1 = new ToolStripButton();
            toolStripButton2 = new ToolStripButton();
            toolStripButton3 = new ToolStripButton();
            toolStripButton4 = new ToolStripButton();
            toolStripButton5 = new ToolStripButton();
            toolStripButton6 = new ToolStripButton();
            toolStripButton7 = new ToolStripButton();
            menuStrip2.SuspendLayout();
            toolStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip2
            // 
            menuStrip2.ImageScalingSize = new Size(20, 20);
            menuStrip2.Items.AddRange(new ToolStripItem[] { menuFile, menuSystem, menuBanking, menuHelp });
            menuStrip2.Location = new Point(0, 0);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(1282, 28);
            menuStrip2.TabIndex = 1;
            menuStrip2.Text = "menuStrip2";
            // 
            // menuFile
            // 
            menuFile.DropDownItems.AddRange(new ToolStripItem[] { menuItemLogin, menuItemLogout });
            menuFile.Name = "menuFile";
            menuFile.Size = new Size(46, 24);
            menuFile.Text = "File";
            // 
            // menuItemLogin
            // 
            menuItemLogin.Name = "menuItemLogin";
            menuItemLogin.Size = new Size(139, 26);
            menuItemLogin.Text = "Login";
            menuItemLogin.Click += clickToPageLogin;
            // 
            // menuItemLogout
            // 
            menuItemLogout.Name = "menuItemLogout";
            menuItemLogout.Size = new Size(139, 26);
            menuItemLogout.Text = "Logout";
            // 
            // menuSystem
            // 
            menuSystem.DropDownItems.AddRange(new ToolStripItem[] { employeeToolStripMenuItem, branchToolStripMenuItem });
            menuSystem.Name = "menuSystem";
            menuSystem.Size = new Size(70, 24);
            menuSystem.Text = "System";
            // 
            // employeeToolStripMenuItem
            // 
            employeeToolStripMenuItem.Name = "employeeToolStripMenuItem";
            employeeToolStripMenuItem.Size = new Size(158, 26);
            employeeToolStripMenuItem.Text = "Employee";
            employeeToolStripMenuItem.Click += clickToPageEmployeeManagement;
            // 
            // branchToolStripMenuItem
            // 
            branchToolStripMenuItem.Name = "branchToolStripMenuItem";
            branchToolStripMenuItem.Size = new Size(158, 26);
            branchToolStripMenuItem.Text = "Branch";
            branchToolStripMenuItem.Click += clickToPageBranchManagement;
            // 
            // menuBanking
            // 
            menuBanking.DropDownItems.AddRange(new ToolStripItem[] { ToolStripMenuItemcreateCustomer, depositAmountToolStripMenuItem, withToolStripMenuItem, transactionAmountToolStripMenuItem, balaceToolStripMenuItem, transactionLogToolStripMenuItem });
            menuBanking.Name = "menuBanking";
            menuBanking.Size = new Size(76, 24);
            menuBanking.Text = "Banking";
            // 
            // ToolStripMenuItemcreateCustomer
            // 
            ToolStripMenuItemcreateCustomer.Name = "ToolStripMenuItemcreateCustomer";
            ToolStripMenuItemcreateCustomer.Size = new Size(222, 26);
            ToolStripMenuItemcreateCustomer.Text = "Create customer";
            ToolStripMenuItemcreateCustomer.Click += clickToPageCustomerManagement;
            // 
            // depositAmountToolStripMenuItem
            // 
            depositAmountToolStripMenuItem.Name = "depositAmountToolStripMenuItem";
            depositAmountToolStripMenuItem.Size = new Size(222, 26);
            depositAmountToolStripMenuItem.Text = "Deposit amount";
            depositAmountToolStripMenuItem.Click += clickToPageAccountManagement;
            // 
            // withToolStripMenuItem
            // 
            withToolStripMenuItem.Name = "withToolStripMenuItem";
            withToolStripMenuItem.Size = new Size(222, 26);
            withToolStripMenuItem.Text = "Withdraw amount";
            // 
            // transactionAmountToolStripMenuItem
            // 
            transactionAmountToolStripMenuItem.Name = "transactionAmountToolStripMenuItem";
            transactionAmountToolStripMenuItem.Size = new Size(222, 26);
            transactionAmountToolStripMenuItem.Text = "Transaction amount";
            transactionAmountToolStripMenuItem.Click += clickToPageTracsactionManagement;
            // 
            // balaceToolStripMenuItem
            // 
            balaceToolStripMenuItem.Name = "balaceToolStripMenuItem";
            balaceToolStripMenuItem.Size = new Size(222, 26);
            balaceToolStripMenuItem.Text = "Balance amount";
            // 
            // transactionLogToolStripMenuItem
            // 
            transactionLogToolStripMenuItem.Name = "transactionLogToolStripMenuItem";
            transactionLogToolStripMenuItem.Size = new Size(222, 26);
            transactionLogToolStripMenuItem.Text = "Transaction log";
            // 
            // menuHelp
            // 
            menuHelp.DropDownItems.AddRange(new ToolStripItem[] { userGuideToolStripMenuItem, aboutToolStripMenuItem });
            menuHelp.Name = "menuHelp";
            menuHelp.Size = new Size(55, 24);
            menuHelp.Text = "Help";
            // 
            // userGuideToolStripMenuItem
            // 
            userGuideToolStripMenuItem.Name = "userGuideToolStripMenuItem";
            userGuideToolStripMenuItem.Size = new Size(163, 26);
            userGuideToolStripMenuItem.Text = "User guide";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(163, 26);
            aboutToolStripMenuItem.Text = "About";
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(20, 20);
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolbarBranchPrint, toolStripButton1, toolStripButton2, toolStripButton3, toolStripButton4, toolStripButton5, toolStripButton6, toolStripButton7 });
            toolStrip1.Location = new Point(0, 28);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(1282, 27);
            toolStrip1.TabIndex = 6;
            toolStrip1.Text = "toolStrip1";
            // 
            // toolbarBranchPrint
            // 
            toolbarBranchPrint.Image = (Image)resources.GetObject("toolbarBranchPrint.Image");
            toolbarBranchPrint.ImageTransparentColor = Color.Magenta;
            toolbarBranchPrint.Name = "toolbarBranchPrint";
            toolbarBranchPrint.Size = new Size(63, 24);
            toolbarBranchPrint.Text = "Print";
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabelBankSystemManagement });
            statusStrip1.Location = new Point(0, 727);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(1282, 26);
            statusStrip1.TabIndex = 7;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelBankSystemManagement
            // 
            toolStripStatusLabelBankSystemManagement.Name = "toolStripStatusLabelBankSystemManagement";
            toolStripStatusLabelBankSystemManagement.Size = new Size(129, 20);
            toolStripStatusLabelBankSystemManagement.Text = "Hân -Bank System";
            // 
            // toolStripButton1
            // 
            toolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton1.Image = (Image)resources.GetObject("toolStripButton1.Image");
            toolStripButton1.ImageTransparentColor = Color.Magenta;
            toolStripButton1.Name = "toolStripButton1";
            toolStripButton1.Size = new Size(29, 24);
            toolStripButton1.Text = "toolStripButton1";
            // 
            // toolStripButton2
            // 
            toolStripButton2.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton2.Image = (Image)resources.GetObject("toolStripButton2.Image");
            toolStripButton2.ImageTransparentColor = Color.Magenta;
            toolStripButton2.Name = "toolStripButton2";
            toolStripButton2.Size = new Size(29, 24);
            toolStripButton2.Text = "toolStripButton2";
            // 
            // toolStripButton3
            // 
            toolStripButton3.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton3.Image = (Image)resources.GetObject("toolStripButton3.Image");
            toolStripButton3.ImageTransparentColor = Color.Magenta;
            toolStripButton3.Name = "toolStripButton3";
            toolStripButton3.Size = new Size(29, 24);
            toolStripButton3.Text = "toolStripButton3";
            // 
            // toolStripButton4
            // 
            toolStripButton4.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton4.Image = (Image)resources.GetObject("toolStripButton4.Image");
            toolStripButton4.ImageTransparentColor = Color.Magenta;
            toolStripButton4.Name = "toolStripButton4";
            toolStripButton4.Size = new Size(29, 24);
            toolStripButton4.Text = "toolStripButton4";
            // 
            // toolStripButton5
            // 
            toolStripButton5.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton5.Image = (Image)resources.GetObject("toolStripButton5.Image");
            toolStripButton5.ImageTransparentColor = Color.Magenta;
            toolStripButton5.Name = "toolStripButton5";
            toolStripButton5.Size = new Size(29, 24);
            toolStripButton5.Text = "toolStripButton5";
            // 
            // toolStripButton6
            // 
            toolStripButton6.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton6.Image = (Image)resources.GetObject("toolStripButton6.Image");
            toolStripButton6.ImageTransparentColor = Color.Magenta;
            toolStripButton6.Name = "toolStripButton6";
            toolStripButton6.Size = new Size(29, 24);
            toolStripButton6.Text = "toolStripButton6";
            // 
            // toolStripButton7
            // 
            toolStripButton7.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton7.Image = (Image)resources.GetObject("toolStripButton7.Image");
            toolStripButton7.ImageTransparentColor = Color.Magenta;
            toolStripButton7.Name = "toolStripButton7";
            toolStripButton7.Size = new Size(29, 24);
            toolStripButton7.Text = "toolStripButton7";
            // 
            // fMainManager
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1282, 753);
            Controls.Add(statusStrip1);
            Controls.Add(toolStrip1);
            Controls.Add(menuStrip2);
            Name = "fMainManager";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hệ thống quản lý";
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip2;
        public ToolStripMenuItem menuFile;
        public ToolStripMenuItem menuItemLogin;
        public ToolStripMenuItem menuItemLogout;
        public ToolStripMenuItem menuSystem;
        public ToolStripMenuItem menuBanking;
        private Button button1;
        private Button button2;
        private ToolStrip toolStrip1;
        private ToolStripButton toolbarBranchPrint;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabelBankSystemManagement;
        private ToolStripMenuItem employeeToolStripMenuItem;
        private ToolStripMenuItem branchToolStripMenuItem;
        private ToolStripMenuItem ToolStripMenuItemcreateCustomer;
        private ToolStripMenuItem depositAmountToolStripMenuItem;
        private ToolStripMenuItem withToolStripMenuItem;
        private ToolStripMenuItem transactionAmountToolStripMenuItem;
        private ToolStripMenuItem balaceToolStripMenuItem;
        private ToolStripMenuItem transactionLogToolStripMenuItem;
        public ToolStripMenuItem menuHelp;
        private ToolStripMenuItem userGuideToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ToolStripButton toolStripButton1;
        private ToolStripButton toolStripButton2;
        private ToolStripButton toolStripButton3;
        private ToolStripButton toolStripButton4;
        private ToolStripButton toolStripButton5;
        private ToolStripButton toolStripButton6;
        private ToolStripButton toolStripButton7;
    }
}