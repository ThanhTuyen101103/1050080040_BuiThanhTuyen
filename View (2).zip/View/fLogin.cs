﻿using bankManagement.Controller;

namespace bankManagement
{
    public partial class fLogin : Form
    {
        private fMainManager mainForm;
        public fLogin(fMainManager form)
        {
            InitializeComponent();
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            mainForm = form;
        }

        private void thoatButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (MessageBox.Show("Bạn muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            //{
            //    e.Cancel = true;
            //}
        }

        private void dangNhapButton_Click(object sender, EventArgs e)
        {
            string userName = txbTenDangNhap.Text;
            string password = txbMatKhau.Text;
            if (Login(userName, password))
            {
                MessageBox.Show("Đăng nhập thành công, đi tới phiên làm việc!");
                mainForm.menuItemLogin.Enabled = false;
                mainForm.menuItemLogout.Enabled = true;
                mainForm.menuSystem.Enabled = true;
                mainForm.menuBanking.Enabled = true;
                mainForm.menuHelp.Enabled = true;

                
                this.Hide();
                mainForm.Show();
            } else 
                {
                    MessageBox.Show("Tên người dùng hoặc mật khẩu sai!");
                }
            
        }

        bool Login(string userName, string password)
        {
            accountController accountController = new accountController();
            return accountController.Login(userName,password);
        }
    }
}
