﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankManagement.Controller
{
    public class connectDBS
    {
        public static SqlConnection getConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-9LUBUCBG;Initial Catalog=bankManagement;User ID=tuyen;Password=0876;Pooling=False;");
            return con;
        }
    }
}
