﻿using bankManagement.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankManagement.Controller
{
    internal class customerController : IController
    {
        SqlConnection conn = connectDBS.getConnection();
        private List<IModel> _items;
        public List<IModel> Items => this._items;

        public customerController()
        {
            _items = new List<IModel>();
        }

        public bool Load()
        {
            try
            {
                conn.Open();
                string query = "SELECT * FROM Customer";
                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    customerModel customerM = new customerModel(
                        reader["id"].ToString(),
                        reader["name"].ToString(),
                        reader["phone"].ToString(),
                        reader["email"].ToString(),
                        reader["house_no"].ToString(),
                        reader["city"].ToString(),
                        reader["pin"].ToString()
                    );
                    _items.Add(customerM);
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();

            }
        }
        public bool IsExist(object model)
        {
            customerModel customerM = (customerModel)model;

            try
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Customer WHERE id = '" + customerM.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool Create(IModel model)
        {
            customerModel customerM = (customerModel)model;
            try
            {
                conn.Open();
                string query = "INSERT INTO Customer (id, name, phone, email, house_no, city, pin) VALUES ('" +
                               customerM.id + "', '" +
                               customerM.name + "', '" +
                               customerM.phone + "', '" +
                               customerM.email + "', '" +
                               customerM.house_no + "', '" +
                               customerM.city + "', '" +
                               customerM.pin + "')";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Update(IModel model)
        {
            customerModel customerM = (customerModel)model;
            try
            {
                conn.Open();
                string query = "UPDATE Customer SET name = '" + customerM.name +
                               "', phone = '" + customerM.phone +
                               "', email = '" + customerM.email +
                               "', house_no = '" + customerM.house_no +
                               "', city = '" + customerM.city +
                               "', pin = '" + customerM.pin +
                               "' WHERE id = '" + customerM.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Delete(IModel model)
        {
            customerModel customerM = (customerModel)model;
            try
            {
                conn.Open();
                string query = "DELETE FROM Customer WHERE id = '" + customerM.id + "'";
                SqlCommand cmd = new SqlCommand(query, conn);

                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
        public bool Load(object id)
        {
            throw new NotImplementedException();
        }

        public IModel Read(object id)
        {
            throw new NotImplementedException();
        }

        
    }
}
